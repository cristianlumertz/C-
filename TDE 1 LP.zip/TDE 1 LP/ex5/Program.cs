﻿double? nota = 7.8;
Console.WriteLine(nota);

﻿string nome = "Maria";
Console.WriteLine(nome);

﻿int x = 77;
int y = 66;
Console.WriteLine(x + y);

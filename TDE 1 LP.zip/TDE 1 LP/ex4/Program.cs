﻿const int ano = 12;
Console.WriteLine(ano);

﻿double altura = 3.45;
Console.WriteLine(altura);

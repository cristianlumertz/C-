﻿int idade = 35;
Console.WriteLine(idade);
